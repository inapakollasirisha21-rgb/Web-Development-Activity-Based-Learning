# College Information & Admissions

Responsive web development activity project.

## Run
Open `index.html` in a modern browser. No build tools are required.

## Files
- `index.html` — semantic page structure and content
- `style.css` — responsive styling, layout, animations and focus states
- `script.js` — navigation and interactive demo behavior

## Notes
This is a front-end demonstration. Replace sample names, contact details, fees and institutional/course information with verified details before submission. Form submissions and enrollment actions are demo-only and do not connect to a backend.
