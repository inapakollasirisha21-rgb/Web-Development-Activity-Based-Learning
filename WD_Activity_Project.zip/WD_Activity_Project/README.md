# Web Development Activity-Based Learning — Project Pack

This pack contains three case studies selected from the supplied task sheet:
1. Personal Portfolio Website
2. College Information and Admissions Website
3. Online Learning Platform Interface

## How to run
1. Extract the ZIP file.
2. Open `WD_Activity_Project/index.html` (or this folder's `index.html`) in Chrome, Edge, Firefox or another modern browser.
3. Select a project card to open the website.
4. Each project folder contains its own `index.html`, `style.css`, `script.js` and `README.md`.

## Implementation
- Semantic HTML and accessible labels
- Responsive layouts for desktop and mobile
- CSS Grid/Flexbox, hover effects and motion preferences
- JavaScript mobile navigation and interactive UI behavior
- Search/filter course cards on the learning platform
- Demo-only contact/enrollment interactions (no backend)

## Important customization checklist
- Replace portfolio sample name, education, skills, projects and email with your actual information.
- Replace college name, programs, contact details and admissions information with verified details if your faculty expects a real institution.
- Confirm any prices and course details before submission.
- Forms and enrollment actions do not send data or create real accounts.
- Google Fonts require an internet connection; fallback fonts are included.
